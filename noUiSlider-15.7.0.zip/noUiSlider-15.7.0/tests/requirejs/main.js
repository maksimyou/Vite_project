require(['/nouislider/dist/nouislider.js'], function(noUiSlider) {
    console.log(noUiSlider); // { create, ... }
});
