slider.noUiSlider.getPositions();
